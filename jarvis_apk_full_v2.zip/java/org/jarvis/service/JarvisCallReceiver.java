package org.jarvis.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.ContactsContract;

import java.util.LinkedList;

public class JarvisCallReceiver extends BroadcastReceiver {

    private static final LinkedList<String> QUEUE = new LinkedList<String>();

    public static String poll() {
        synchronized (QUEUE) {
            if (QUEUE.isEmpty()) {
                return null;
            }
            return QUEUE.removeFirst();
        }
    }

    @Override
    public void onReceive(Context ctx, Intent intent) {
        try {
            String state = intent.getStringExtra("state");
            String number = intent.getStringExtra("incoming_number");
            if (state == null) {
                return;
            }
            if (number == null) {
                number = "";
            }
            String name = "";
            if (number.length() > 0) {
                Cursor c = null;
                try {
                    Uri uri = Uri.withAppendedPath(
                            ContactsContract.PhoneLookup.CONTENT_FILTER_URI,
                            Uri.encode(number));
                    c = ctx.getContentResolver().query(
                            uri,
                            new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME},
                            null, null, null);
                    if (c != null && c.moveToFirst()) {
                        name = c.getString(0);
                    }
                } catch (Throwable e) {
                    // ignore
                } finally {
                    if (c != null) {
                        c.close();
                    }
                }
            }
            synchronized (QUEUE) {
                QUEUE.add(state + "\t" + number + "\t" + (name == null ? "" : name));
                while (QUEUE.size() > 20) {
                    QUEUE.removeFirst();
                }
            }
        } catch (Throwable e) {
            // ignore
        }
    }
}
