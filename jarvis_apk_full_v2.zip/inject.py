"""Run once before the build: puts the two Jarvis services into the
python-for-android manifest template and copies the accessibility config."""
import os
import shutil
import sys

P4A = sys.argv[1] if len(sys.argv) > 1 else "p4a"
services = open("manifest_services.xml", encoding="utf-8").read()

templates = []
res_dirs = []

for root, dirs, files in os.walk(P4A):
    if "AndroidManifest.tmpl.xml" in files:
        templates.append(os.path.join(root, "AndroidManifest.tmpl.xml"))
    if root.replace("\\", "/").endswith("build/src/main/res"):
        res_dirs.append(root)

if not templates:
    sys.exit("ERROR: AndroidManifest.tmpl.xml not found in " + P4A)

for path in templates:
    text = open(path, encoding="utf-8").read()
    if "JarvisNotifService" in text:
        continue
    if text.count("</application>") != 1:
        sys.exit("ERROR: expected one </application> in " + path)
    text = text.replace("</application>", services + "\n    </application>")
    open(path, "w", encoding="utf-8").write(text)
    print("patched", path)

if not res_dirs:
    sys.exit("ERROR: res folder not found in " + P4A)

for d in res_dirs:
    os.makedirs(os.path.join(d, "xml"), exist_ok=True)
    shutil.copy("res_extra/accessibility_config.xml", os.path.join(d, "xml"))
    print("copied config to", d)
