[app]
title = Jarvis
package.name = jarvis
package.domain = org.jarvis
source.dir = .
source.include_exts = py,png,jpg,kv,atlas,ttf
version = 1.0
requirements = python3,kivy==2.3.0,pyjnius,requests,urllib3,idna,charset-normalizer,certifi
orientation = portrait
fullscreen = 0

android.permissions = INTERNET,RECORD_AUDIO,CALL_PHONE,SEND_SMS,READ_CONTACTS,CAMERA,READ_EXTERNAL_STORAGE,WRITE_EXTERNAL_STORAGE,VIBRATE,MODIFY_AUDIO_SETTINGS,POST_NOTIFICATIONS,ACCESS_NETWORK_STATE,CHANGE_WIFI_STATE,ACCESS_WIFI_STATE,BLUETOOTH,WAKE_LOCK,FOREGROUND_SERVICE,READ_PHONE_STATE,READ_CALL_LOG,ANSWER_PHONE_CALLS

# target 29 keeps normal file access (DCIM, Pictures, Music) working
android.api = 29
android.minapi = 24
android.ndk = 25b
android.archs = arm64-v8a
android.accept_sdk_license = True
android.extra_manifest_application_arguments = ./legacy_storage.xml
android.add_src = java
p4a.source_dir = ./p4a

[buildozer]
log_level = 2
warn_on_root = 1
