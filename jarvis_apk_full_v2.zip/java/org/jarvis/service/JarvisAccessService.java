package org.jarvis.service;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.List;

public class JarvisAccessService extends AccessibilityService {

    private static JarvisAccessService inst = null;

    @Override
    protected void onServiceConnected() {
        inst = this;
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
    }

    @Override
    public void onInterrupt() {
    }

    @Override
    public boolean onUnbind(Intent intent) {
        inst = null;
        return super.onUnbind(intent);
    }

    public static boolean isRunning() {
        return inst != null;
    }

    public static boolean doGlobal(int action) {
        try {
            return inst != null && inst.performGlobalAction(action);
        } catch (Throwable e) {
            return false;
        }
    }

    public static boolean clickText(String text) {
        try {
            if (inst == null) {
                return false;
            }
            AccessibilityNodeInfo root = inst.getRootInActiveWindow();
            if (root == null) {
                return false;
            }
            List<AccessibilityNodeInfo> list = root.findAccessibilityNodeInfosByText(text);
            if (list == null) {
                return false;
            }
            for (int i = 0; i < list.size(); i++) {
                AccessibilityNodeInfo c = list.get(i);
                int guard = 0;
                while (c != null && !c.isClickable() && guard < 8) {
                    c = c.getParent();
                    guard++;
                }
                if (c != null && c.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true;
                }
            }
            return false;
        } catch (Throwable e) {
            return false;
        }
    }

    private static AccessibilityNodeInfo findScrollable(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 25) {
            return null;
        }
        if (n.isScrollable()) {
            return n;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findScrollable(n.getChild(i), depth + 1);
            if (r != null) {
                return r;
            }
        }
        return null;
    }

    public static boolean scroll(boolean forward) {
        try {
            if (inst == null) {
                return false;
            }
            AccessibilityNodeInfo root = inst.getRootInActiveWindow();
            AccessibilityNodeInfo s = findScrollable(root, 0);
            if (s == null) {
                return false;
            }
            return s.performAction(forward
                    ? AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
                    : AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD);
        } catch (Throwable e) {
            return false;
        }
    }

    private static void collect(AccessibilityNodeInfo n, StringBuilder sb, int depth) {
        if (n == null || depth > 25 || sb.length() > 1500) {
            return;
        }
        CharSequence t = n.getText();
        if (t == null || t.length() == 0) {
            t = n.getContentDescription();
        }
        if (t != null && t.length() > 0) {
            sb.append(t.toString().replace("\n", " ")).append(". ");
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            collect(n.getChild(i), sb, depth + 1);
        }
    }

    public static String readScreen() {
        try {
            if (inst == null) {
                return "";
            }
            StringBuilder sb = new StringBuilder();
            collect(inst.getRootInActiveWindow(), sb, 0);
            return sb.toString();
        } catch (Throwable e) {
            return "";
        }
    }

    private static AccessibilityNodeInfo findEditable(AccessibilityNodeInfo n, int depth) {
        if (n == null || depth > 25) {
            return null;
        }
        if (n.isEditable()) {
            return n;
        }
        for (int i = 0; i < n.getChildCount(); i++) {
            AccessibilityNodeInfo r = findEditable(n.getChild(i), depth + 1);
            if (r != null) {
                return r;
            }
        }
        return null;
    }

    public static boolean setText(String text) {
        try {
            if (inst == null) {
                return false;
            }
            AccessibilityNodeInfo root = inst.getRootInActiveWindow();
            if (root == null) {
                return false;
            }
            AccessibilityNodeInfo t = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT);
            if (t == null || !t.isEditable()) {
                t = findEditable(root, 0);
            }
            if (t == null) {
                return false;
            }
            Bundle b = new Bundle();
            b.putCharSequence(
                    AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text);
            return t.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b);
        } catch (Throwable e) {
            return false;
        }
    }
}
