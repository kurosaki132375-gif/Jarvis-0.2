JARVIS APK - full project
Files: main.py, buildozer.spec, legacy_storage.xml, inject.py, manifest_services.xml,
       java/ (2 files), res_extra/ (1 file), .github/workflows/build.yml
1. GitHub e notun PRIVATE repo banao
2. Shob file/folder upload koro (folder shoho). build.yml ta ".github/workflows/build.yml" naame
3. Actions > Build Jarvis APK > Run workflow
4. Shesh hole "jarvis-apk" download > zip khule APK install

APK install er por:
- App khule Allow chap (mic, call, SMS...)
- Phone Settings > Apps > Jarvis > 3 dot > "Allow restricted settings"
- Notification access ON + Accessibility ON (Jarvis)
- Battery > Jarvis > Unrestricted

Notun (v2): call answer/reject, background listening (Hey Jarvis), talk mode,
best voice, message messenger/instagram/telegram/whatsapp, type, search in app.
Extra permission: Phone/Call log (allow koro), Battery > Unrestricted.
