package org.jarvis.service;

import android.app.Notification;
import android.app.RemoteInput;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;

public class JarvisNotifService extends NotificationListenerService {

    private static final LinkedList<String> QUEUE = new LinkedList<String>();
    private static final Map<String, Notification.Action> ACTIONS =
            new HashMap<String, Notification.Action>();
    private static Context appContext = null;
    private static volatile boolean connected = false;

    @Override
    public void onListenerConnected() {
        connected = true;
        appContext = getApplicationContext();
    }

    @Override
    public void onListenerDisconnected() {
        connected = false;
    }

    private static String clean(CharSequence cs) {
        if (cs == null) {
            return "";
        }
        return cs.toString().replace("\t", " ").replace("\n", " ").replace("\r", " ");
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        try {
            if (sbn == null) {
                return;
            }
            if (appContext == null) {
                appContext = getApplicationContext();
            }
            Notification n = sbn.getNotification();
            if (n == null) {
                return;
            }
            if ((n.flags & Notification.FLAG_GROUP_SUMMARY) != 0) {
                return;
            }
            Bundle ex = n.extras;
            if (ex == null) {
                return;
            }
            String title = clean(ex.getCharSequence(Notification.EXTRA_TITLE));
            String text = clean(ex.getCharSequence(Notification.EXTRA_TEXT));
            String pkg = sbn.getPackageName();
            String key = sbn.getKey();

            if (n.actions != null) {
                for (int i = 0; i < n.actions.length; i++) {
                    Notification.Action a = n.actions[i];
                    if (a != null && a.getRemoteInputs() != null
                            && a.getRemoteInputs().length > 0) {
                        synchronized (ACTIONS) {
                            if (ACTIONS.size() > 40) {
                                ACTIONS.clear();
                            }
                            ACTIONS.put(key, a);
                        }
                        break;
                    }
                }
            }

            String line = pkg + "\t" + title + "\t" + text + "\t" + key;
            synchronized (QUEUE) {
                QUEUE.add(line);
                while (QUEUE.size() > 50) {
                    QUEUE.removeFirst();
                }
            }
        } catch (Throwable e) {
            // ignore
        }
    }

    public static String poll() {
        synchronized (QUEUE) {
            if (QUEUE.isEmpty()) {
                return null;
            }
            return QUEUE.removeFirst();
        }
    }

    public static boolean isConnected() {
        return connected;
    }

    public static boolean hasReply(String key) {
        synchronized (ACTIONS) {
            return ACTIONS.containsKey(key);
        }
    }

    public static boolean reply(String key, String text) {
        try {
            Notification.Action a;
            synchronized (ACTIONS) {
                a = ACTIONS.get(key);
            }
            if (a == null || appContext == null) {
                return false;
            }
            RemoteInput[] inputs = a.getRemoteInputs();
            Intent intent = new Intent();
            Bundle results = new Bundle();
            for (int i = 0; i < inputs.length; i++) {
                results.putCharSequence(inputs[i].getResultKey(), text);
            }
            RemoteInput.addResultsToIntent(inputs, intent, results);
            a.actionIntent.send(appContext, 0, intent);
            return true;
        } catch (Throwable e) {
            return false;
        }
    }
}
