package org.jarvis.service;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;

import java.util.ArrayList;
import java.util.LinkedList;

public class JarvisListenService extends Service {

    private static final LinkedList<String> QUEUE = new LinkedList<String>();
    private static volatile boolean running = false;
    private static volatile String lang = "en-US";

    private SpeechRecognizer sr = null;
    private Handler handler = null;

    private final Runnable startRun = new Runnable() {
        @Override
        public void run() {
            beginListening();
        }
    };

    public static void setLang(String l) {
        lang = l;
    }

    public static boolean isRunning() {
        return running;
    }

    public static String poll() {
        synchronized (QUEUE) {
            if (QUEUE.isEmpty()) {
                return null;
            }
            return QUEUE.removeFirst();
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private Notification buildNotification() {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
            NotificationChannel ch = new NotificationChannel(
                    "jarvis_listen", "Jarvis listening", NotificationManager.IMPORTANCE_LOW);
            nm.createNotificationChannel(ch);
            b = new Notification.Builder(this, "jarvis_listen");
        } else {
            b = new Notification.Builder(this);
        }
        b.setContentTitle("Jarvis is listening");
        b.setContentText("Say: Hey Jarvis");
        b.setSmallIcon(android.R.drawable.ic_btn_speak_now);
        return b.build();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        try {
            startForeground(7701, buildNotification());
        } catch (Throwable e) {
            // ignore
        }
        if (!running) {
            running = true;
            handler = new Handler(Looper.getMainLooper());
            handler.post(startRun);
        }
        return START_STICKY;
    }

    private void restart(long ms) {
        if (!running || handler == null) {
            return;
        }
        handler.removeCallbacks(startRun);
        handler.postDelayed(startRun, ms);
    }

    private void beginListening() {
        if (!running) {
            return;
        }
        try {
            if (sr == null) {
                sr = SpeechRecognizer.createSpeechRecognizer(this);
                sr.setRecognitionListener(listener);
            }
            Intent rec = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            rec.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                    RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            rec.putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang);
            rec.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            rec.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            sr.startListening(rec);
        } catch (Throwable e) {
            restart(2000);
        }
    }

    private final RecognitionListener listener = new RecognitionListener() {
        @Override
        public void onReadyForSpeech(Bundle params) {
        }

        @Override
        public void onBeginningOfSpeech() {
        }

        @Override
        public void onRmsChanged(float rmsdB) {
        }

        @Override
        public void onBufferReceived(byte[] buffer) {
        }

        @Override
        public void onEndOfSpeech() {
        }

        @Override
        public void onError(int error) {
            if (error == 8) {
                try {
                    if (sr != null) {
                        sr.destroy();
                    }
                } catch (Throwable e) {
                    // ignore
                }
                sr = null;
                restart(1500);
            } else {
                restart(400);
            }
        }

        @Override
        public void onResults(Bundle results) {
            try {
                ArrayList<String> list =
                        results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                if (list != null && list.size() > 0) {
                    String text = list.get(0);
                    if (text != null && text.trim().length() > 0) {
                        synchronized (QUEUE) {
                            QUEUE.add(text.trim());
                            while (QUEUE.size() > 20) {
                                QUEUE.removeFirst();
                            }
                        }
                    }
                }
            } catch (Throwable e) {
                // ignore
            }
            restart(300);
        }

        @Override
        public void onPartialResults(Bundle partialResults) {
        }

        @Override
        public void onEvent(int eventType, Bundle params) {
        }
    };

    @Override
    public void onDestroy() {
        running = false;
        try {
            if (handler != null) {
                handler.removeCallbacks(startRun);
            }
            if (sr != null) {
                sr.destroy();
            }
        } catch (Throwable e) {
            // ignore
        }
        sr = null;
        super.onDestroy();
    }
}
